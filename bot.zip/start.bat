py main.py
pause
